package com.practice.notesapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class NoteListActivity : AppCompatActivity() {

    private lateinit var noteAdapter: NotesAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var db: NotesDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_list)

        db = NotesDatabaseHelper(this)

        recyclerView = findViewById(R.id.recyclerViewNotes)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Set up the adapter with data from the database
        noteAdapter = NotesAdapter(db.getAllNotes(), this)
        recyclerView.adapter = noteAdapter
    }
}
