package com.practice.notesapp

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate

class ModeChangeActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var switchModeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mode_change)

        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE)
        switchModeButton = findViewById(R.id.switchModeButton)

        if (sharedPreferences.getBoolean("isDarkMode", false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            switchModeButton.text = "Switch to Light Mode"
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            switchModeButton.text = "Switch to Dark Mode"
        }

        switchModeButton.setOnClickListener {
            toggleMode()
        }
    }

    private fun toggleMode() {
        val isDarkMode = sharedPreferences.getBoolean("isDarkMode", false)

        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            sharedPreferences.edit().putBoolean("isDarkMode", false).apply()
            switchModeButton.text = "Switch to Dark Mode"
            Toast.makeText(this, "Light Mode Enabled", Toast.LENGTH_SHORT).show()
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            sharedPreferences.edit().putBoolean("isDarkMode", true).apply()
            switchModeButton.text = "Switch to Light Mode"
            Toast.makeText(this, "Dark Mode Enabled", Toast.LENGTH_SHORT).show()
        }
    }
}
