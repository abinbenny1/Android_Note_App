package com.practice.notesapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button

class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        val getStartedButton: Button = findViewById(R.id.getStartedButton)
        val modeChangeButton: Button = findViewById(R.id.modeChangeButton)
        val viewNotesButton: Button = findViewById(R.id.viewNotesButton)

        getStartedButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        modeChangeButton.setOnClickListener {
            startActivity(Intent(this, ModeChangeActivity::class.java))
        }

        viewNotesButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("viewNotesOnly", true) // Optional, in case you want to handle this later
            startActivity(intent)
        }

        viewNotesButton.setOnClickListener {
            val intent = Intent(this, NoteListActivity::class.java)
            startActivity(intent)
        }

    }
}
